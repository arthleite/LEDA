package adt.queue;

public class QueueImpl<T> implements Queue<T> {

	protected T[] array;
	protected int tail;

	@SuppressWarnings("unchecked")
	public QueueImpl(int size) {
		array = (T[]) new Object[size];
		tail = -1;
	}

	@Override
	public T head() {
		T result = null;
        if (!isEmpty()) {
            result = array[0];
        }
        return result;
	}

	@Override
	public boolean isEmpty() {
		return tail == -1;
	}

	@Override
	public boolean isFull() {
		return tail == array.length - 1;
	}

	@SuppressWarnings("unused")
	private void shiftLeft() {
		for (int i = 0; i < tail; i++) {
            array[i] = array[i + 1];
        }
        array[tail] = null;
	}

	@Override
	public void enqueue(T element) throws QueueOverflowException {
		if(isFull()){
			throw new QueueOverflowException();
		}else{
			array[++tail] = element;
		}

	}

	@Override
	public T dequeue() throws QueueUnderflowException {
		T result = null;
		if(!isEmpty()){
			result = array[0];
			shiftLeft();
			tail--;
		}else{
			throw new QueueUnderflowException();
		}
		return result;
	}

}
